#!/usr/bin/python

import select, socket, sys, time

def usage(msg=""):
    if msg:
        print msg
    print "%s [host] path [interval]" % sys.argv[0]
    sys.exit(1)

running = False


def download(host, path, interval):
    count = 0
    t = 0
    req = None
    req = "\r\n".join(["GET %s HTTP/1.0" % path, "Host: %s" % host, "Accept: */*", "User-Agent: Download speed monitor/0.1", "", ""])
    sck = None
    start = 0
    global running
    try:
        if sck is None:
            count = 0
            start = int(time.time())
            t = start / interval
            sck = socket.socket()
            sck.connect((socket.gethostbyname(host), 80))
            #print >> sys.stderr, "req:\n", req
            sck.sendall(req)
        sck.setblocking(False)
        
        poll = select.poll()
        poll.register(sck, select.POLLIN)
        while running:
            ret = poll.poll(1000)
            for fd, evt in ret:
                data = sck.recv(4096)
                if data == "":
                    continue
                count += len(data)
            else:
                pass
            now = int(time.time()) / interval
            if now != t:
                print "%d,%.3f" % (now * interval - start, float(count) / 128 / interval)
                sys.stdout.flush()
                t = now
                count = 0
    except Exception, e:
        print >> sys.stderr, "Error happens: ", str(e)


if __name__ == "__main__":
    host = "127.0.0.1"
    path = "/"
    interval = 3
    l = len(sys.argv)
    if l == 2:
        path = sys.argv[1]
    elif l == 3:
        host = sys.argv[1]
        path = sys.argv[2]
    elif l == 4:
        host = sys.argv[1]
        path = sys.argv[2]
        interval = int(sys.argv[3])
    else:
        usage() 
    
    running = True
    if not path.startswith("/"):
        path = "/" + path
    download(host, path, interval)

