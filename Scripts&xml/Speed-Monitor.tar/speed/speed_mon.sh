#!/bin/bash
set +x

declare -a GUIDS
GUIDS=("cctv1hd")

SPEED_MON(){
	SCRIPT_PATH="/root/speed"
	SCRIPT_NAME="download_speed_monitor.py"
	HOST="127.0.0.1"
	REPORT_INTERVAL="10"
	LOG_PATH="/tmp/download_speed_monitor"
	if [ ! -e "$LOG_PATH" ];then
		mkdir -p $LOG_PATH
	fi
	kill -9 `ps -ef | grep "$SCRIPT_NAME" | grep -v "grep" | awk '{print $2}' | xargs`
	for GUID in ${GUIDS[@]}
	do
		python $SCRIPT_PATH/$SCRIPT_NAME "$HOST" "live/$GUID" $REPORT_INTERVAL >> $LOG_PATH/$GUID-local.log &
	done
}

#CHNL_STAT=`/SO/bin/cns-walk -d -g cctvhd | awk '{print $3}' | awk -F'=|,' '{print $2}'`
#if [ "$CHNL_STAT" -eq "1" ];then
#	exit
#else
	SPEED_MON
#fi
